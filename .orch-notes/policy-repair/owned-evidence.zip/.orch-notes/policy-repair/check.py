import json, subprocess, sys, time, os
sys.stdout.reconfigure(encoding="utf-8")
os.environ["PYTHONIOENCODING"]="utf-8"
from pathlib import Path
root=Path.cwd(); out=root/'.orch-notes/policy-repair'
label=sys.argv[1]; argv=[sys.executable,*sys.argv[2:]]
r=subprocess.run(argv,cwd=root,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=600)
(out/(label+'.log')).write_text(r.stdout+r.stderr,encoding='utf-8')
with (out/'commands.jsonl').open('a',encoding='utf-8') as f: f.write(json.dumps({'label':label,'argv':argv,'exit':r.returncode})+'\n')
print(label, 'exit',r.returncode); print((r.stdout+r.stderr)[-16000:]); sys.exit(r.returncode)
