import json, sys
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
from tests.test_review_delivery_carriage import ReviewCarriageTest
from scripts.tickets_format import _parse_frontmatter, _sections
rows=[]
for method in ['test_recipe_preserves_context_adapter_method_and_private_pins','test_independent_game_and_video_stage_commands_forward_effective_rounds']:
 test=ReviewCarriageTest(method)
 test.setUp()
 try:
  getattr(test,method)()
  rows.append({'test':method,'run':test.fixture.RUN,'tickets':[
   {'id':p.stem,'fields':_parse_frontmatter(p.read_text(encoding='utf-8')),
    'context':_sections(p.read_text(encoding='utf-8')).get('Context')}
   for p in sorted(test.fixture.run_dir().glob('*.md'))]})
 finally: test.doCleanups()
Path('.orch-notes/policy-repair/recipe-observations.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
print('Captured',sum(len(row['tickets']) for row in rows),'fixture tickets; both tests passed. Public dispatch/pin/Context/adapter seams real; workspace establishment stubbed. No live prose invocation claimed.')
