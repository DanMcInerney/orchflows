import json, subprocess, sys
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
from tools.validate import body_words
from tools.validate_support.packages import parse_frontmatter, Diagnostics
from tests.test_cell_linter_cases.warning_ratchets import ceiling_breach
from tests.test_cell_linter_cases.standard_cells import CROSS_TIER, CROSS_TIER_WARNING_CEILING, warning_lines
out=Path('.orch-notes/policy-repair')
counts={label:len(warning_lines((out/name).read_text(encoding='utf-8'),CROSS_TIER)) for label,name in [('before','baseline-validate.log'),('after','validate-final.log')]}
assert counts=={'before':33,'after':24},counts
assert ceiling_breach(counts['before'],CROSS_TIER_WARNING_CEILING,CROSS_TIER)
assert ceiling_breach(counts['after'],CROSS_TIER_WARNING_CEILING,CROSS_TIER) is None
budgets={name:body_words(parse_frontmatter(Path(name).read_text(encoding='utf-8'), name, Diagnostics())[1] if name.endswith('SKILL.md') else Path(name).read_text(encoding='utf-8')) for name in ['templates/host-block.md','example-workflows/benchmaker/workflows/benchmark-calibrate/SKILL.md','example-workflows/3d-browser-game/SKILL.md','example-workflows/tiktok-video/SKILL.md','skills/workflows/review-delivery/SKILL.md']}
result={'cross_tier':counts,'ceiling':CROSS_TIER_WARNING_CEILING,'can_fail':'baseline33 breaches unchanged29; repaired24 does not','body_words':budgets}
(out/'admission-readings.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result))
